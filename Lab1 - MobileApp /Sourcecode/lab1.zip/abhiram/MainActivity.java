package com.example.ram.abhiram;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ram.fblogintest.R;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

public class MainActivity extends AppCompatActivity {
    LoginButton fblogin_button;
    CallbackManager callbackManager;
    private static EditText username;
    private static EditText password;
    private static Button login_button;
    private static Button forgot_pwd;
    private static Button home_vbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.activity_main);
        username = (EditText) findViewById(R.id.input_email);
        password = (EditText) findViewById(R.id.input_password);

        Login_button();
        forgotPassword();
        initilalizeControls();
        loginwithFacebook();
    }

    private void initilalizeControls(){
        callbackManager = CallbackManager.Factory.create();
        fblogin_button = (LoginButton)findViewById(R.id.login_button);
    }

    private void loginwithFacebook(){
        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, LoggedinActivity.class);
                startActivity(intent);
            }

            @Override
            public void onCancel() {

                //txtstatus.setText("LoginCancelled\n");
            }

            @Override
            public void onError(FacebookException error) {
                //txtstatus.setText("LoginError"+error.getMessage());
            }
        });
    }

    private void Login_button(){
        login_button = (Button) findViewById(R.id.btn_login);
        login_button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                // Stores User name
                String un = String.valueOf(username.getText());
                // Stores Password
                String pw = String.valueOf(password.getText());

                // Validates the User name and Password for admin, admin
                if (un.equals("admin") && pw.equals("admin")) {
                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, LoggedinActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Login UnSuccessful. Please try again", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void forgotPassword(){
        forgot_pwd = (Button)findViewById(R.id.buttonfgtpwd);
        forgot_pwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(HomeActivity.this, "This option is not yet available. Please bear with us. \n Thank you", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(MainActivity.this, ForgotPwdActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }
}
