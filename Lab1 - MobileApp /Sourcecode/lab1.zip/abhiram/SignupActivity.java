package com.example.ram.abhiram;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.ram.fblogintest.R;

public class SignupActivity extends AppCompatActivity {
    Button btn_signedup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        signedup();
    }
    private void signedup(){
        btn_signedup = (Button)findViewById(R.id.btn_signedup);
        btn_signedup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignupActivity.this, LoggedinActivity.class);
                startActivity(intent);
            }
        });
    }
}
